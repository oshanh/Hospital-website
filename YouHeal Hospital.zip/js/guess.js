function fun(){

var data=document.getElementsByName("sleep");

    if(sleep[0].checked){
        var score=score+(sleep[0].value);
        alert(score);

    }




}